<?php

$logfile = 'demo_scores.csv';
$xfile = 'demo_scoresx.csv';
$rightpass = "secret";

$description = "<h2 align='center'>Security+ Mini Questions</h2>";

$removes = array("Module01", "Module02" ); # text to remove from score labels

$poss_chals = array("LABEL_Category Module01", "1.2", "1.3", "1.4", "1.5", "1.6" ,"BREAK",
		"LABEL_Category Module02", "2.2", "2.4", "BREAK",
		"LABEL_Category Module03", "3.2", "3.3", "BREAK",

);

$correct_answers = array(
  array( "1.2", "123456", 5 ),
  array( "1.3", "availability", 5 ),
  array( "1.4", "4.8 million", 5 ),
  array( "1.5", "Google Cloud Platform", 5 ),
  array( "1.6", "Google PersistentDisk", 5 ),

  array( "2.2", "eicar", 5 ),
  array( "2.4", "tailgator", 5 ),

  array( "3.2", "", 5 ),


); 

?>
