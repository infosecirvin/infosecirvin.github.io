#!/bin/bash

chmod 777 lamectf/*.csv